// using space
using System;

namespace _20230911_Alarm_Okumura.Sys
{
    public static class SystemLog
    {
        // Request int in console
        public static string RequestTime = "Please input time(Minutes): ";

        // Request int HH:MM in console
        public static string RequestClock = "Please input time(HHMM): ";

        // Error
        public static string InvalidInput = "Invalid input. Please try again.";
    }
}
