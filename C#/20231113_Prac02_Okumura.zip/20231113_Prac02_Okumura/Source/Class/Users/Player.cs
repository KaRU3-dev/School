using System;

using _20231113_Prac02_Okumura.Interface;

namespace _20231113_Prac02_Okumura.Game.User{
    public class Player : Users{

        public float HP{get; set;}

        public int Num1{get; set;}
        public int Num2{get; set;}
        public int Num3{get; set;}
    }
}
