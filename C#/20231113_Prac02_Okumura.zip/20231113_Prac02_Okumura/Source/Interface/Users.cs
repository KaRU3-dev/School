using System;

namespace _20231113_Prac02_Okumura.Interface{
    public interface Users{
        public float HP{get; set;}
        public int Num1{get; set;}
        public int Num2{get; set;}
        public int Num3{get; set;}
    }
}
