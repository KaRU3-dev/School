using System;

namespace _20231113_Prac02_Okumura.Abstract{}
namespace _20231113_Prac02_Okumura.Interface{}
namespace _20231113_Prac02_Okumura.Game{}
namespace _20231113_Prac02_Okumura.Game.User{}
