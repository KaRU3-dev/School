using System;

namespace Game.Characters.Interface
{
    public interface IAttackable
    {
        int Attack();
    }
}
