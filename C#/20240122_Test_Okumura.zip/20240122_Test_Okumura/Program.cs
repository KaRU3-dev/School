﻿using System;

using GameEngine;

class Program
{
    static void Main()
    {
        Game game = new Game();
        game.StartGame();
    }
}
